package dev.hadron.collider.content;

import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;

/** A rare, visibly energized product of collider experiments. */
public class AntimatterCellItem extends Item {
    public AntimatterCellItem(Properties properties) {
        super(properties);
    }

    @Override
    public boolean isFoil(ItemStack stack) {
        return true;
    }
}
