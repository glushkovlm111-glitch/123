package dev.hadron.collider.registry;

import dev.hadron.collider.CHCMod;
import dev.hadron.collider.content.ColliderConsoleBlock;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.SoundType;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.material.MapColor;
import net.neoforged.neoforge.registries.DeferredRegister;
import net.neoforged.neoforge.registries.DeferredHolder;

public final class CHCBlocks {
    public static final DeferredRegister.Blocks BLOCKS = DeferredRegister.createBlocks(CHCMod.MOD_ID);

    public static final DeferredHolder<Block, Block> SUPERCONDUCTING_MAGNET = BLOCKS.register(
        "superconducting_magnet",
        () -> new Block(BlockBehaviour.Properties.of()
            .mapColor(MapColor.COLOR_LIGHT_GRAY).strength(4.0F, 6.0F)
            .sound(SoundType.METAL).requiresCorrectToolForDrops())
    );

    public static final DeferredHolder<Block, Block> ACCELERATOR_CAVITY = BLOCKS.register(
        "accelerator_cavity",
        () -> new Block(BlockBehaviour.Properties.of()
            .mapColor(MapColor.COLOR_CYAN).strength(3.5F, 5.0F)
            .sound(SoundType.METAL).requiresCorrectToolForDrops())
    );

    public static final DeferredHolder<Block, Block> COLLIDER_CONSOLE = BLOCKS.register(
        "collider_console",
        () -> new ColliderConsoleBlock(BlockBehaviour.Properties.of()
            .mapColor(MapColor.COLOR_BLUE).strength(3.0F, 5.0F)
            .sound(SoundType.METAL).requiresCorrectToolForDrops())
    );

    private CHCBlocks() {}
}
