package dev.hadron.collider.content;

import com.mojang.serialization.MapCodec;
import dev.hadron.collider.registry.CHCBlockEntities;
import net.minecraft.core.BlockPos;
import net.minecraft.network.chat.Component;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.BaseEntityBlock;
import net.minecraft.world.level.block.RenderShape;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.entity.BlockEntityTicker;
import net.minecraft.world.level.block.entity.BlockEntityType;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.BlockHitResult;
import org.jetbrains.annotations.Nullable;

public class ColliderConsoleBlock extends BaseEntityBlock {
    public static final MapCodec<ColliderConsoleBlock> CODEC = simpleCodec(ColliderConsoleBlock::new);
    public ColliderConsoleBlock(Properties properties) { super(properties); }
    @Override public MapCodec<ColliderConsoleBlock> codec() { return CODEC; }
    @Override public RenderShape getRenderShape(BlockState state) { return RenderShape.MODEL; }
    @Override public BlockEntity newBlockEntity(BlockPos pos, BlockState state) {
        return new ColliderConsoleBlockEntity(pos, state);
    }

    @Override
    protected InteractionResult useWithoutItem(BlockState state, Level level, BlockPos pos, Player player, BlockHitResult hit) {
        if (level.isClientSide) return InteractionResult.SUCCESS;
        BlockEntity be = level.getBlockEntity(pos);
        if (be instanceof ColliderConsoleBlockEntity console) {
            if (player.isShiftKeyDown()) {
                player.displayClientMessage(Component.literal(
                    "Коллайдер: " + (console.isRunning() ? "РАБОТАЕТ" : "ОСТАНОВЛЕН")
                    + " | RPM: " + console.getLastRpm() + "/128"
                    + " | Заряд: " + console.getCharge() + "/1000"
                    + " | Столкновения: " + console.getCollisions()
                    + " | Ячейки антиматерии: " + console.getAntimatterCellsGenerated()
                    + " | " + console.getStatus()), false);
            } else {
                console.toggle();
                player.displayClientMessage(Component.literal(console.getStatus()), true);
            }
        }
        return InteractionResult.CONSUME;
    }

    @Override
    public <T extends BlockEntity> @Nullable BlockEntityTicker<T> getTicker(
        Level level, BlockState state, BlockEntityType<T> type) {
        return level.isClientSide ? null : createTickerHelper(
            type, CHCBlockEntities.COLLIDER_CONSOLE.get(), ColliderConsoleBlockEntity::serverTick);
    }
}
