package dev.hadron.collider;

import dev.hadron.collider.registry.CHCBlocks;
import dev.hadron.collider.registry.CHCBlockEntities;
import dev.hadron.collider.registry.CHCCreativeTabs;
import dev.hadron.collider.registry.CHCItems;
import net.neoforged.bus.api.IEventBus;
import net.neoforged.fml.common.Mod;
import net.neoforged.fml.javafmlmod.FMLJavaModLoadingContext;

@Mod(CHCMod.MOD_ID)
public final class CHCMod {
    public static final String MOD_ID = "create_hadron_collider";

    public CHCMod(FMLJavaModLoadingContext context) {
        IEventBus modBus = context.getModEventBus();
        CHCBlocks.BLOCKS.register(modBus);
        CHCItems.ITEMS.register(modBus);
        CHCBlockEntities.TYPES.register(modBus);
        CHCCreativeTabs.TABS.register(modBus);
    }
}
