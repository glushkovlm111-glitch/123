package dev.hadron.collider.registry;

import dev.hadron.collider.CHCMod;
import net.minecraft.core.registries.Registries;
import net.minecraft.network.chat.Component;
import net.minecraft.world.item.CreativeModeTab;
import net.minecraft.world.item.ItemStack;
import net.neoforged.neoforge.registries.DeferredRegister;
import net.neoforged.neoforge.registries.DeferredHolder;

public final class CHCCreativeTabs {
    public static final DeferredRegister<CreativeModeTab> TABS =
        DeferredRegister.create(Registries.CREATIVE_MODE_TAB, CHCMod.MOD_ID);

    public static final DeferredHolder<CreativeModeTab, CreativeModeTab> MAIN = TABS.register("main", () ->
        CreativeModeTab.builder()
            .title(Component.translatable("itemGroup.create_hadron_collider"))
            .icon(() -> new ItemStack(CHCBlocks.COLLIDER_CONSOLE.get()))
            .displayItems((parameters, output) -> {
                output.accept(CHCBlocks.COLLIDER_CONSOLE.get());
                output.accept(CHCBlocks.SUPERCONDUCTING_MAGNET.get());
                output.accept(CHCBlocks.ACCELERATOR_CAVITY.get());
                output.accept(CHCItems.ANTIMATTER_CELL.get());
            })
            .build());

    private CHCCreativeTabs() {}
}
