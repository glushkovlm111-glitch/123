package dev.hadron.collider.registry;

import dev.hadron.collider.CHCMod;
import dev.hadron.collider.content.ColliderConsoleBlockEntity;
import net.minecraft.core.registries.Registries;
import net.minecraft.world.level.block.entity.BlockEntityType;
import net.neoforged.neoforge.registries.DeferredRegister;
import net.neoforged.neoforge.registries.DeferredHolder;

public final class CHCBlockEntities {
    public static final DeferredRegister<BlockEntityType<?>> TYPES =
        DeferredRegister.create(Registries.BLOCK_ENTITY_TYPE, CHCMod.MOD_ID);

    public static final DeferredHolder<BlockEntityType<?>, BlockEntityType<ColliderConsoleBlockEntity>> COLLIDER_CONSOLE =
        TYPES.register("collider_console", () -> BlockEntityType.Builder.of(
            ColliderConsoleBlockEntity::new, CHCBlocks.COLLIDER_CONSOLE.get()).build(null));

    private CHCBlockEntities() {}
}
