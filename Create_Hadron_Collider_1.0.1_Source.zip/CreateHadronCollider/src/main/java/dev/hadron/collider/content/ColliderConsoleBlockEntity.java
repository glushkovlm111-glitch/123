package dev.hadron.collider.content;

import com.simibubi.create.content.kinetics.base.KineticBlockEntity;
import dev.hadron.collider.registry.CHCBlockEntities;
import dev.hadron.collider.registry.CHCBlocks;
import dev.hadron.collider.registry.CHCItems;
import net.minecraft.world.entity.item.ItemEntity;
import net.minecraft.world.item.ItemStack;
import net.minecraft.core.BlockPos;
import net.minecraft.core.HolderLookup;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.chat.Component;
import net.minecraft.world.level.Level;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.state.BlockState;

/** Server-side controller for the 64-point collider ring. */
public class ColliderConsoleBlockEntity extends BlockEntity {
    public static final int MIN_INPUT_RPM = 128;
    public static final int MAX_CHARGE = 1000;
    private static final int COLLISION_CHARGE_COST = 1000;

    private boolean running;
    private int collisions;
    private int antimatterCellsGenerated;
    private static final int COLLISIONS_PER_ANTIMATTER_CELL = 5;
    private static final int CHARGE_PER_TICK_INTERVAL = 2;
    private static final int RING_RADIUS = 32;
    private int charge;
    private int tickCounter;
    private int lastRpm;
    private String status = "Ожидание запуска";

    public ColliderConsoleBlockEntity(BlockPos pos, BlockState state) {
        super(CHCBlockEntities.COLLIDER_CONSOLE.get(), pos, state);
    }

    public boolean isRunning() { return running; }
    public int getCollisions() { return collisions; }
    public int getAntimatterCellsGenerated() { return antimatterCellsGenerated; }
    public int getCharge() { return charge; }
    public int getLastRpm() { return lastRpm; }
    public String getStatus() { return status; }

    public void toggle() {
        if (level == null || level.isClientSide) return;
        if (running) {
            stop("Коллайдер остановлен оператором");
            return;
        }

        StructureCheck check = checkStructureAndPower();
        lastRpm = check.rpm();
        if (!check.valid()) {
            status = check.message();
            setChanged();
            return;
        }
        running = true;
        tickCounter = 0;
        status = "Запуск разрешён · вход " + lastRpm + " RPM · заряд " + charge + "/" + MAX_CHARGE;
        setChanged();
    }

    /** Called by the block entity ticker once per server tick. */
    public static void serverTick(Level level, BlockPos pos, BlockState state, ColliderConsoleBlockEntity be) {
        if (level.isClientSide || !be.running) return;

        StructureCheck check = be.checkStructureAndPower();
        be.lastRpm = check.rpm();
        if (!check.valid()) {
            be.stop("АВАРИЙНОЕ ОТКЛЮЧЕНИЕ · " + check.message());
            return;
        }

        // The kinetic input is validated continuously. Charge is a gameplay buffer,
        // not a claim that Create's network stress is physically consumed yet.
        be.tickCounter++;
        if (be.tickCounter % CHARGE_PER_TICK_INTERVAL == 0 && be.charge < MAX_CHARGE) {
            be.charge++;
            be.setChanged();
        }

        if (be.charge >= COLLISION_CHARGE_COST) {
            be.charge -= COLLISION_CHARGE_COST;
            be.collisions++;
            if (level instanceof ServerLevel serverLevel) {
                serverLevel.sendParticles(ParticleTypes.END_ROD, pos.getX() + 0.5, pos.getY() + 1.2, pos.getZ() + 0.5, 18, 0.65, 0.35, 0.65, 0.025);
                serverLevel.sendParticles(ParticleTypes.PORTAL, pos.getX() + 0.5, pos.getY() + 1.0, pos.getZ() + 0.5, 28, 0.8, 0.5, 0.8, 0.15);
            }
            if (be.collisions % COLLISIONS_PER_ANTIMATTER_CELL == 0) {
                ItemStack cell = new ItemStack(CHCItems.ANTIMATTER_CELL.get(), 1);
                ItemEntity output = new ItemEntity(level,
                    pos.getX() + 0.5, pos.getY() + 1.1, pos.getZ() + 0.5, cell);
                output.setDefaultPickUpDelay();
                level.addFreshEntity(output);
                be.antimatterCellsGenerated++;
                be.status = "АНТИМАТЕРИЯ СОЗДАНА · ячеек: " + be.antimatterCellsGenerated
                    + " · столкновение №" + be.collisions;
            } else {
                int remaining = COLLISIONS_PER_ANTIMATTER_CELL - (be.collisions % COLLISIONS_PER_ANTIMATTER_CELL);
                be.status = "Столкновение №" + be.collisions + " · до ячейки антиматерии: " + remaining;
            }
            level.sendBlockUpdated(pos, state, state, 3);
            be.setChanged();
        } else if (be.tickCounter % 20 == 0) {
            be.status = "Разгон активен · " + be.lastRpm + " RPM · накопление " + be.charge + "/" + MAX_CHARGE;
            be.setChanged();
        }
    }

    private void stop(String reason) {
        running = false;
        status = reason;
        setChanged();
        if (level != null) level.sendBlockUpdated(worldPosition, getBlockState(), getBlockState(), 3);
    }

    private StructureCheck checkStructureAndPower() {
        if (level == null) return new StructureCheck(false, 0, "Мир ещё не загружен");
        int magnets = 0;
        int cavities = 0;
        for (int i = 0; i < 64; i++) {
            double angle = (Math.PI * 2.0 * i) / 64.0;
            int x = worldPosition.getX() + (int) Math.round(Math.cos(angle) * RING_RADIUS);
            int z = worldPosition.getZ() + (int) Math.round(Math.sin(angle) * RING_RADIUS);
            BlockPos ringPos = new BlockPos(x, worldPosition.getY(), z);
            if (level.getBlockState(ringPos).is(CHCBlocks.SUPERCONDUCTING_MAGNET.get())) magnets++;
            if (level.getBlockState(ringPos).is(CHCBlocks.ACCELERATOR_CAVITY.get())) cavities++;
        }
        if (magnets < 48 || cavities < 8)
            return new StructureCheck(false, 0, "Кольцо не собрано: магниты " + magnets + "/48, камеры " + cavities + "/8");

        // The console's kinetic input is the Create shaft/kinetic block directly
        // touching one of its six faces. Do not accept an unrelated machine several
        // blocks away: the player must physically connect the drive to the console.
        int bestRpm = 0;
        for (net.minecraft.core.Direction direction : net.minecraft.core.Direction.values()) {
            BlockPos inputPos = worldPosition.relative(direction);
            if (level.getBlockEntity(inputPos) instanceof KineticBlockEntity kinetic) {
                int rpm = (int) Math.floor(Math.abs(kinetic.getSpeed()));
                if (rpm > bestRpm) bestRpm = rpm;
            }
        }
        if (bestRpm < MIN_INPUT_RPM)
            return new StructureCheck(false, bestRpm, "Нет прямого кинетического входа или скорость мала: " + bestRpm + "/" + MIN_INPUT_RPM + " RPM");
        return new StructureCheck(true, bestRpm, "OK");
    }

    @Override
    protected void saveAdditional(CompoundTag tag, HolderLookup.Provider registries) {
        super.saveAdditional(tag, registries);
        tag.putBoolean("Running", running);
        tag.putInt("Collisions", collisions);
        tag.putInt("AntimatterCellsGenerated", antimatterCellsGenerated);
        tag.putInt("Charge", charge);
        tag.putInt("TickCounter", tickCounter);
        tag.putInt("LastRPM", lastRpm);
        tag.putString("Status", status);
    }

    @Override
    protected void loadAdditional(CompoundTag tag, HolderLookup.Provider registries) {
        super.loadAdditional(tag, registries);
        // Never resume an active accelerator automatically after a world reload.
        // This prevents a loaded machine from starting without an operator check.
        running = false;
        collisions = tag.getInt("Collisions");
        antimatterCellsGenerated = tag.getInt("AntimatterCellsGenerated");
        charge = Math.max(0, Math.min(MAX_CHARGE, tag.getInt("Charge")));
        tickCounter = tag.getInt("TickCounter");
        lastRpm = tag.getInt("LastRPM");
        status = tag.getString("Status");
        if (tag.getBoolean("Running")) status = "Остановлен после загрузки мира · проверьте конструкцию и запустите вручную";
    }

    private record StructureCheck(boolean valid, int rpm, String message) {}
}
