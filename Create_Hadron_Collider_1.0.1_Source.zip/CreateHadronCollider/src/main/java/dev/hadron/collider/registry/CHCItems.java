package dev.hadron.collider.registry;

import dev.hadron.collider.CHCMod;
import dev.hadron.collider.content.AntimatterCellItem;
import net.minecraft.world.item.BlockItem;
import net.minecraft.world.item.Item;
import net.neoforged.neoforge.registries.DeferredRegister;
import net.neoforged.neoforge.registries.DeferredHolder;

public final class CHCItems {
    public static final DeferredRegister.Items ITEMS = DeferredRegister.createItems(CHCMod.MOD_ID);

    public static final DeferredHolder<Item, Item> SUPERCONDUCTING_MAGNET_ITEM =
        ITEMS.register("superconducting_magnet", () -> new BlockItem(CHCBlocks.SUPERCONDUCTING_MAGNET.get(), new Item.Properties()));
    public static final DeferredHolder<Item, Item> ACCELERATOR_CAVITY_ITEM =
        ITEMS.register("accelerator_cavity", () -> new BlockItem(CHCBlocks.ACCELERATOR_CAVITY.get(), new Item.Properties()));
    public static final DeferredHolder<Item, Item> COLLIDER_CONSOLE_ITEM =
        ITEMS.register("collider_console", () -> new BlockItem(CHCBlocks.COLLIDER_CONSOLE.get(), new Item.Properties()));
    public static final DeferredHolder<Item, Item> ANTIMATTER_CELL =
        ITEMS.register("antimatter_cell", () -> new AntimatterCellItem(new Item.Properties().stacksTo(16)));

    private CHCItems() {}
}
