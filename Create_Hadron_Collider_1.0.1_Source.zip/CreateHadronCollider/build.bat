@echo off
chcp 65001 >nul
cd /d "%~dp0"
echo Сборка Create: Hadron Collider 1.0.0
java -version || (echo Нужен JDK 21 & pause & exit /b 1)
where gradle >nul 2>nul || (echo Gradle 8.10+ не найден в PATH & pause & exit /b 1)
gradle clean build --no-daemon
if errorlevel 1 (echo Ошибка сборки. Проверь версии зависимостей и вывод Gradle. & pause & exit /b 1)
echo Готовый JAR находится в build\libs
explorer "%~dp0build\libs"
pause
